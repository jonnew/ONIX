Material type: FR4 Material 
thickness: 0.02" 
Layers: 2 
Dimensions: 0.49" x 0.705" 
Finish plating: Immersion gold 
Smallest hole size: 0.006" 
Solder mask color: black 
Silkscreen color: white